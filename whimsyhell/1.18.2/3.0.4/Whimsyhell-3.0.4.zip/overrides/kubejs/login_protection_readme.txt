LOGIN PROTECTION SCRIPT
By LadyLexxie 2022

For any information, support, issue, or suggestion ping me on the official KubeJS Discord server: https://discord.gg/bPFfH6P
My name is Lady Lexxie#6969

This script will enable player invulnerability on login, until the player presses any button or click.
The invulnerability will protect the player from any damage source (except falling into the void), and will make all hostile mobs ignore the player.
To install the scripts, simply drag the "kubejs" folder into the already existing "kubejs" folder.
